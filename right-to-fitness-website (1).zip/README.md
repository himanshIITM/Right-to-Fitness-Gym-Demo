# Right to Fitness — Website

A single-page, mobile-first website for Right to Fitness Gym & Personal Training (Tagore Town, Varanasi).

## Files

- `index.html` — the entire website (HTML, CSS, and JS are all in this one file)
- `robots.txt` — search engine crawling rules
- `sitemap.xml` — sitemap for SEO

## Editing business info

All editable business details (phone number, address, hours, Google rating/review count, Maps link, Instagram) live in one place near the top of `index.html`, inside the `RTF_CONFIG` object:

```js
const RTF_CONFIG = {
  name: "Right to Fitness",
  phoneDisplay: "+91 63863 75619",
  phoneHref: "+916386375619",
  whatsappNumber: "916386375619",
  address: { ... },
  rating: 4.8,
  reviews: 289,
  hours: { ... },
  mapsUrl: "...",
  mapsEmbedSrc: "...",
  instagramUrl: ""
};
```

Update the values there and the whole site updates automatically — no need to hunt through the page.

## Deploying with GitHub Pages

1. Create a new GitHub repository and upload these files to the root (or push via git).
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`.
4. Save. GitHub will give you a live URL like `https://<username>.github.io/<repo-name>/` within a minute or two.
5. Once you have a custom domain, update the `<link rel="canonical">` tag, the two `application/ld+json` schema blocks, and `sitemap.xml` to use that domain instead of the placeholder `righttofitness.example`.

## Notes

- No backend is required — the trial booking form and all enquiry buttons hand off to WhatsApp with a pre-filled message.
- Photos throughout are temporary stock placeholders; swap the `<img src="...">` URLs with real gym photos when available.
- Testimonials are placeholders by design — replace with real Google reviews once the owner provides them.
